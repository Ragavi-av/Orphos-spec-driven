# Orphos EIP — portable sample data

A shareable, tenant-agnostic dataset for the Orphos knowledge-graph demo
entities. Import it into any ArcadeDB `orphos` database, for any tenant.

## Files

| File | Purpose |
|------|---------|
| `SampleDataGenerator.java` | Java generator (source of truth). Regenerates the `.sql`. |
| `orphos-sample-data.sql`   | Generated seed script — **this is the importable artifact**. |
| `ImportSampleData.java`    | Java importer — substitutes the tenant token and loads the script over the HTTP API in chunks. |

## What's inside

**1000 records per entity** across 8 vertex types and 6 edge types:

| Vertex type | Edge types |
|-------------|------------|
| `ITSystem`, `Incident`, `SLAMetric`, `CostCentre`, `BudgetItem`, `Alert`, `Decision`, `Project` | `HAS_INCIDENT`, `HAS_SLA_METRIC`, `TRIGGERS`, `FUNDS`, `IMPACTS`, `DEPENDS_ON` |

Field shapes match what the platform services query (fields such as
`tenantId`, `affectedSystem`, `metricName`, `status`, `severity`, `domain`,
`budget/spent/variance`, `progress`, …), so the rows render on the dashboard
rather than sitting invisible.

The script is structured as: **schema DDL** (idempotent `CREATE ... IF NOT
EXISTS`) → **per-tenant clear** (`DELETE VERTEX ... WHERE tenantId=...`) →
**inserts** → **edges**. Re-importing for the same tenant is safe — the clear
block removes that tenant's rows first.

## Import

> Find a tenant's UUID with `SELECT id, domain FROM Tenant`. The bundled demo
> tenant (`localhost`) is `127a2ec3-cb19-365e-9ebe-c9c19ed5e5d8`.

### Easiest — the bundled Java importer

Substitutes the tenant token and posts the script in chunks over the HTTP API.
Reads `ARCADEDB_PASSWORD` from the repo `.env` automatically. Run from this
directory:

```bash
java ImportSampleData.java 127a2ec3-cb19-365e-9ebe-c9c19ed5e5d8
```

Full form: `java ImportSampleData.java <tenantId> [sqlFile] [host] [db] [chunkSize]`
(defaults: `orphos-sample-data.sql`, `http://localhost:2480`, `orphos`, `250`).

### Manual alternative

1. **Substitute the tenant token** — replace every `__TENANT_ID__` with the
   tenant UUID:

   ```bash
   sed 's/__TENANT_ID__/127a2ec3-cb19-365e-9ebe-c9c19ed5e5d8/g' orphos-sample-data.sql > orphos-sample-data.tenant.sql
   ```

   PowerShell: `(Get-Content orphos-sample-data.sql) -replace '__TENANT_ID__','<uuid>' | Set-Content orphos-sample-data.tenant.sql`

2. **Load it** — paste into ArcadeDB Studio's SQL console (`http://localhost:2480`),
   or POST the contents to `/api/v1/command/orphos` with `language: sqlscript`
   (split a 3–4 MB file into a few-hundred-statement chunks to stay within
   request-size limits).

## Regenerating

```bash
java SampleDataGenerator.java [recordsPerEntity] [outputFile]
# default: 1000 orphos-sample-data.sql
```

Output is deterministic (fixed RNG seed) — the same inputs produce a
byte-identical file, so it diffs cleanly in git.

## Multi-tenant note

Indexes are compound `(tenantId, id) UNIQUE`, so the same file can seed
several tenants into one shared `orphos` DB without id collisions. If the DB
still carries a legacy bare `Incident(id) UNIQUE` / `Alert(id) UNIQUE` index
(from the old `init-arcadedb-schema.bat`), drop those first, since they would
reject the same `inc-*`/`alr-*` ids under a second tenant.
